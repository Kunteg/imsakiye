<?php
// Direkt erişim engellendi
header("Location: /imsakiye");
exit;
?>
