<footer class="footer">
    <p>&copy; <?php echo date('Y'); ?> e-icerik.net | Tüm Hakları Saklıdır</p>
    <p>İftar ve sahur vakitleri anlık olarak güncellenmektedir.</p>
</footer>

<style>
.footer {
    background: #2F6D2F; /* Koyu Yeşil */
    color: #FFF;
    text-align: center;
    padding: 15px;
    font-size: 1rem;
    margin-top: 30px;
}

.footer p {
    margin: 5px 0;
    font-weight: bold;
}

.footer a {
    color: #FFD700; /* Altın Sarısı */
    text-decoration: none;
    font-weight: bold;
}

.footer a:hover {
    text-decoration: underline;
}
</style>
